/*
SQLyog Community v13.2.0 (64 bit)
MySQL - 10.4.32-MariaDB : Database - saas_admin_panel
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`saas_admin_panel` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `saas_admin_panel`;

/*Table structure for table `activity_logs` */

DROP TABLE IF EXISTS `activity_logs`;

CREATE TABLE `activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `vendor_id` bigint(20) unsigned DEFAULT NULL,
  `log_name` varchar(191) NOT NULL DEFAULT 'default',
  `description` varchar(191) NOT NULL,
  `event` varchar(191) DEFAULT NULL,
  `subject_type` varchar(191) DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(191) DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `url` varchar(191) DEFAULT NULL,
  `method` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_logs_log_name_index` (`log_name`),
  KEY `activity_logs_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `activity_logs_causer_type_causer_id_index` (`causer_type`,`causer_id`),
  KEY `activity_logs_user_id_index` (`user_id`),
  KEY `activity_logs_vendor_id_index` (`vendor_id`),
  KEY `activity_logs_created_at_index` (`created_at`),
  CONSTRAINT `activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `activity_logs_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `activity_logs` */

insert  into `activity_logs`(`id`,`user_id`,`vendor_id`,`log_name`,`description`,`event`,`subject_type`,`subject_id`,`causer_type`,`causer_id`,`properties`,`old_values`,`new_values`,`ip_address`,`user_agent`,`url`,`method`,`created_at`,`updated_at`) values 
(1,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 21:46:47','2026-03-08 21:46:47'),
(2,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 21:46:47','2026-03-08 21:46:47'),
(3,1,NULL,'vendor','Vendor \'Morissette-Haag\' was updated','updated','App\\Models\\Vendor',3,'App\\Models\\User',1,'{\"id\":3,\"owner_id\":5,\"name\":\"Morissette-Haag\",\"slug\":\"morissette-haag\",\"description\":\"Quas voluptate qui fugiat provident esse earum minus. Velit cum id blanditiis esse labore enim ducimus similique. Ab harum et quis aut aliquam voluptas accusantium. Ipsa debitis voluptatum impedit doloremque.\",\"email\":\"kozey.mayra@schinner.com\",\"phone\":null,\"website\":\"http:\\/\\/www.schuppe.org\\/\",\"logo\":null,\"favicon\":null,\"address\":null,\"city\":null,\"state\":null,\"country\":null,\"postal_code\":null,\"business_type\":null,\"tax_id\":null,\"registration_number\":null,\"status\":\"approved\",\"approved_at\":\"2026-03-08T21:40:02.000000Z\",\"approved_by\":1,\"rejection_reason\":null,\"custom_domain\":null,\"custom_domain_verified\":false,\"primary_color\":\"#c9e849\",\"secondary_color\":\"#f4f3a5\",\"settings\":{\"Coffee\":null},\"total_users\":0,\"total_products\":839,\"total_orders\":598,\"total_revenue\":\"97816.96\",\"trial_ends_at\":\"2026-03-17T00:01:38.000000Z\",\"is_trial\":false,\"created_at\":\"2026-03-08T21:40:02.000000Z\",\"updated_at\":\"2026-03-08T21:51:38.000000Z\",\"deleted_at\":null,\"logo_url\":null,\"favicon_url\":null,\"full_address\":null,\"is_on_trial\":false,\"trial_days_left\":null,\"status_badge\":{\"label\":\"Approved\",\"color\":\"success\"}}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 21:51:38','2026-03-08 21:51:38'),
(4,1,1,'subscription','Subscription was canceled','canceled','App\\Models\\Subscription',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:53:18','2026-03-08 21:53:18'),
(5,1,NULL,'payment','Payment PAY-20260308-ODONIT was created','created','App\\Models\\Payment',9,'App\\Models\\User',1,'{\"vendor_id\":\"9\",\"subscription_id\":\"1\",\"plan_id\":\"3\",\"payment_number\":\"PAY-20260308-ODONIT\",\"description\":null,\"amount\":\"9.00\",\"tax_amount\":\"0.00\",\"discount_amount\":\"1.00\",\"currency\":\"USD\",\"payment_method\":\"paypal\",\"payment_method_details\":\"4554\",\"status\":\"pending\",\"paid_at\":null,\"refunded_at\":null,\"refunded_amount\":\"0.00\",\"billing_name\":\"Saas\",\"billing_email\":\"noor14@gmail.com\",\"billing_address\":\"Peshawar\",\"billing_city\":\"Peshawar\",\"billing_state\":null,\"billing_country\":\"Pakistan\",\"billing_postal_code\":\"25000\",\"stripe_payment_intent_id\":\"54576htyuyu\",\"stripe_charge_id\":\"12454\",\"stripe_invoice_id\":\"4555676\",\"notes\":\"jhyj jmtyut\",\"metadata\":{\"yuyuyuyuy\":\"uyuyuy\"},\"user_id\":1,\"total_amount\":\"8.00\",\"updated_at\":\"2026-03-08T21:56:10.000000Z\",\"created_at\":\"2026-03-08T21:56:10.000000Z\",\"id\":9,\"formatted_amount\":\"$9.00\",\"formatted_total\":\"$8.00\",\"status_badge\":{\"label\":\"Pending\",\"color\":\"warning\"},\"is_paid\":false,\"is_refunded\":false}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 21:56:10','2026-03-08 21:56:10'),
(6,1,9,'payment','Payment PAY-20260308-ODONIT was marked as paid','paid','App\\Models\\Payment',9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:56:28','2026-03-08 21:56:28'),
(7,1,NULL,'auth','User \'Super Admin\' logged out','logout','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/logout','POST','2026-03-08 21:59:25','2026-03-08 21:59:25'),
(8,1,NULL,'auth','User \'Super Admin\' logged out','logout','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/logout','POST','2026-03-08 21:59:25','2026-03-08 21:59:25'),
(9,2,NULL,'auth','User \'Admin User\' logged in','login','App\\Models\\User',2,'App\\Models\\User',2,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 21:59:49','2026-03-08 21:59:49'),
(10,2,NULL,'auth','User \'Admin User\' logged in','login','App\\Models\\User',2,'App\\Models\\User',2,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 21:59:49','2026-03-08 21:59:49'),
(11,2,NULL,'auth','User \'Admin User\' logged out','logout','App\\Models\\User',2,'App\\Models\\User',2,'{\"ip\":\"127.0.0.1\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/logout','POST','2026-03-08 22:01:08','2026-03-08 22:01:08'),
(12,2,NULL,'auth','User \'Admin User\' logged out','logout','App\\Models\\User',2,'App\\Models\\User',2,'{\"ip\":\"127.0.0.1\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/logout','POST','2026-03-08 22:01:08','2026-03-08 22:01:08'),
(13,3,NULL,'auth','User \'Casimir Adams\' logged in','login','App\\Models\\User',3,'App\\Models\\User',3,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 22:01:17','2026-03-08 22:01:17'),
(14,3,NULL,'auth','User \'Casimir Adams\' logged in','login','App\\Models\\User',3,'App\\Models\\User',3,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 22:01:17','2026-03-08 22:01:17'),
(15,3,NULL,'auth','User \'Casimir Adams\' logged out','logout','App\\Models\\User',3,'App\\Models\\User',3,'{\"ip\":\"127.0.0.1\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/logout','POST','2026-03-08 22:05:20','2026-03-08 22:05:20'),
(16,3,NULL,'auth','User \'Casimir Adams\' logged out','logout','App\\Models\\User',3,'App\\Models\\User',3,'{\"ip\":\"127.0.0.1\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/logout','POST','2026-03-08 22:05:20','2026-03-08 22:05:20'),
(17,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 22:06:05','2026-03-08 22:06:05'),
(18,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 22:06:05','2026-03-08 22:06:05'),
(19,1,NULL,'setting','Setting \'branding.logo\' was updated','updated','App\\Models\\Setting',7,'App\\Models\\User',1,'{\"id\":7,\"group\":\"branding\",\"key\":\"logo\",\"value\":\"Saas(78\",\"type\":\"string\",\"is_public\":false,\"description\":null,\"created_at\":\"2026-03-08T21:39:59.000000Z\",\"updated_at\":\"2026-03-08T22:14:42.000000Z\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-08 22:14:42','2026-03-08 22:14:42'),
(20,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:03:21','2026-03-11 11:03:21'),
(21,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:03:21','2026-03-11 11:03:21'),
(22,1,NULL,'vendor','Vendor \'Testing1\' was created','created','App\\Models\\Vendor',11,'App\\Models\\User',1,'{\"name\":\"Testing1\",\"slug\":\"testing1\",\"description\":\"This is testing of testing1\",\"owner_id\":\"2\",\"email\":\"test@test.com\",\"phone\":\"12245564\",\"website\":\"http:\\/\\/www.schuppe.org\\/\",\"address\":\"Peshawar\",\"city\":\"Peshawar\",\"state\":\"kpk\",\"country\":\"Pakistan\",\"postal_code\":\"25000\",\"business_type\":\"Normal\",\"tax_id\":\"242ZXSDe\",\"registration_number\":\"ETRDVCR65\",\"status\":\"suspended\",\"custom_domain\":\"customer.com\",\"logo\":null,\"favicon\":null,\"primary_color\":\"#eb1d1d\",\"secondary_color\":\"#948080\",\"is_trial\":true,\"trial_ends_at\":\"2026-03-25T11:08:34.000000Z\",\"settings\":[],\"updated_at\":\"2026-03-11T11:08:34.000000Z\",\"created_at\":\"2026-03-11T11:08:34.000000Z\",\"id\":11,\"logo_url\":null,\"favicon_url\":null,\"full_address\":\"Peshawar, Peshawar, kpk, 25000, Pakistan\",\"is_on_trial\":true,\"trial_days_left\":13,\"status_badge\":{\"label\":\"Suspended\",\"color\":\"danger\"}}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:08:34','2026-03-11 11:08:34'),
(23,1,11,'vendor','Vendor \'Testing1\' was activated','activated',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:10:52','2026-03-11 11:10:52'),
(24,1,11,'vendor','Vendor \'Testing1\' was suspended','suspended',NULL,NULL,NULL,NULL,'{\"reason\":null}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:11:04','2026-03-11 11:11:04'),
(25,1,NULL,'vendor','Vendor \'Testing1\' was updated','updated','App\\Models\\Vendor',11,'App\\Models\\User',1,'{\"id\":11,\"owner_id\":2,\"name\":\"Testing1\",\"slug\":\"testing1\",\"description\":\"This is testing of testing1\",\"email\":\"test@test.com\",\"phone\":\"12245564\",\"website\":\"http:\\/\\/www.schuppe.org\\/\",\"logo\":null,\"favicon\":null,\"address\":\"Peshawar\",\"city\":\"Peshawar\",\"state\":\"kpk\",\"country\":\"Pakistan\",\"postal_code\":\"25000\",\"business_type\":\"Normal\",\"tax_id\":\"242ZXSDe\",\"registration_number\":\"ETRDVCR65\",\"status\":\"suspended\",\"approved_at\":null,\"approved_by\":null,\"rejection_reason\":null,\"custom_domain\":\"customer.com\",\"custom_domain_verified\":false,\"primary_color\":\"#eb1d1d\",\"secondary_color\":\"#948080\",\"settings\":{\"test\":\"245\"},\"total_users\":0,\"total_products\":0,\"total_orders\":0,\"total_revenue\":\"0.00\",\"trial_ends_at\":\"2026-03-25T11:08:34.000000Z\",\"is_trial\":true,\"created_at\":\"2026-03-11T11:08:34.000000Z\",\"updated_at\":\"2026-03-11T11:11:39.000000Z\",\"deleted_at\":null,\"logo_url\":null,\"favicon_url\":null,\"full_address\":\"Peshawar, Peshawar, kpk, 25000, Pakistan\",\"is_on_trial\":true,\"trial_days_left\":13,\"status_badge\":{\"label\":\"Suspended\",\"color\":\"danger\"}}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:11:39','2026-03-11 11:11:39'),
(26,2,NULL,'auth','User \'Admin User\' logged in','login','App\\Models\\User',2,'App\\Models\\User',2,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/vendor/login-as/11','GET','2026-03-11 11:27:57','2026-03-11 11:27:57'),
(27,2,NULL,'auth','User \'Admin User\' logged in','login','App\\Models\\User',2,'App\\Models\\User',2,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/admin/vendor/login-as/11','GET','2026-03-11 11:27:57','2026-03-11 11:27:57'),
(28,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:34:32','2026-03-11 11:34:32'),
(29,1,NULL,'auth','User \'Super Admin\' logged in','login','App\\Models\\User',1,'App\\Models\\User',1,'{\"ip\":\"127.0.0.1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/145.0.0.0 Safari\\/537.36\"}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:34:32','2026-03-11 11:34:32'),
(30,1,NULL,'plan','Plan \'Free222\' was updated','updated','App\\Models\\Plan',1,'App\\Models\\User',1,'{\"id\":1,\"name\":\"Free222\",\"slug\":\"free\",\"description\":\"Perfect for getting started with basic features.\",\"price\":\"0.00\",\"currency\":\"USD\",\"billing_cycle\":\"monthly\",\"trial_days\":0,\"is_active\":true,\"is_featured\":false,\"is_default\":true,\"sort_order\":1,\"max_vendors\":1,\"max_users_per_vendor\":2,\"max_products\":20,\"max_storage_mb\":100,\"max_api_calls_per_day\":100,\"has_custom_domain\":false,\"has_priority_support\":false,\"has_advanced_analytics\":false,\"has_white_label\":false,\"features\":[{\"icon\":\"heroicon-o-check\",\"label\":\"Up to 20 products\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"2 team members\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"100 MB storage\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"Email support\",\"value\":null}],\"metadata\":[],\"stripe_price_id\":null,\"stripe_product_id\":null,\"created_at\":\"2026-03-08T21:40:02.000000Z\",\"updated_at\":\"2026-03-11T11:46:48.000000Z\",\"deleted_at\":null,\"formatted_price\":\"Free\",\"price_per_month\":0,\"is_free\":true,\"display_features\":[{\"icon\":\"heroicon-o-users\",\"label\":\"Team Members\",\"value\":2},{\"icon\":\"heroicon-o-cube\",\"label\":\"Products\",\"value\":20},{\"icon\":\"heroicon-o-server\",\"label\":\"Storage\",\"value\":\"100 MB\"},{\"icon\":\"heroicon-o-bolt\",\"label\":\"API Calls\",\"value\":\"100\\/day\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Up to 20 products\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"2 team members\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"100 MB storage\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"Email support\",\"value\":null}]}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:46:48','2026-03-11 11:46:48'),
(31,1,1,'subscription','Subscription was resumed','resumed','App\\Models\\Subscription',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:52:47','2026-03-11 11:52:47'),
(32,1,1,'subscription','Subscription was canceled','canceled','App\\Models\\Subscription',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:53:04','2026-03-11 11:53:04'),
(33,1,1,'subscription','Subscription was resumed','resumed','App\\Models\\Subscription',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:53:13','2026-03-11 11:53:13'),
(34,1,1,'subscription','Subscription was canceled','canceled','App\\Models\\Subscription',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:53:23','2026-03-11 11:53:23'),
(35,1,1,'subscription','Subscription was resumed','resumed','App\\Models\\Subscription',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:53:33','2026-03-11 11:53:33'),
(36,1,9,'payment','Payment PAY-20260308-ODONIT was refunded','refunded','App\\Models\\Payment',9,NULL,NULL,'{\"refund_amount\":6,\"total_refunded\":6}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-11 11:55:07','2026-03-11 11:55:07'),
(37,1,NULL,'payment','Payment PAY-20260308-ODONIT was updated','updated','App\\Models\\Payment',9,'App\\Models\\User',1,'{\"id\":9,\"vendor_id\":9,\"subscription_id\":1,\"user_id\":1,\"plan_id\":3,\"payment_number\":\"PAY-20260308-ODONIT\",\"description\":null,\"amount\":\"9.00\",\"currency\":\"USD\",\"tax_amount\":\"0.00\",\"discount_amount\":\"1.00\",\"total_amount\":\"8.00\",\"payment_method\":\"paypal\",\"payment_method_details\":\"4554\",\"stripe_payment_intent_id\":\"54576htyuyu\",\"stripe_charge_id\":\"12454\",\"stripe_invoice_id\":\"4555676\",\"status\":\"partially_refunded\",\"paid_at\":\"2026-03-08T21:56:28.000000Z\",\"refunded_at\":\"2026-03-11T11:55:07.000000Z\",\"refunded_amount\":\"6.00\",\"failure_reason\":null,\"billing_name\":\"Saas\",\"billing_email\":\"noor14@gmail.com\",\"billing_address\":\"Peshawar\",\"billing_city\":\"Peshawar\",\"billing_state\":null,\"billing_country\":\"Pakistan\",\"billing_postal_code\":\"25000\",\"metadata\":{\"yuyuyuyuy\":\"uyuyuy\"},\"notes\":\"jhyj jmtyut\",\"created_at\":\"2026-03-08T21:56:10.000000Z\",\"updated_at\":\"2026-03-11T11:55:07.000000Z\",\"deleted_at\":null,\"formatted_amount\":\"$9.00\",\"formatted_total\":\"$8.00\",\"status_badge\":{\"label\":\"Partially Refunded\",\"color\":\"secondary\"},\"is_paid\":false,\"is_refunded\":true}',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','http://127.0.0.1:8000/livewire/update','POST','2026-03-11 11:55:29','2026-03-11 11:55:29');

/*Table structure for table `cache` */

DROP TABLE IF EXISTS `cache`;

CREATE TABLE `cache` (
  `key` varchar(191) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `cache` */

insert  into `cache`(`key`,`value`,`expiration`) values 
('livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3','i:1;',1773228931),
('livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3:timer','i:1773228931;',1773228931),
('settings:features.enable_trial','b:1;',1773230914),
('settings:features.trial_days','i:14;',1773230914),
('spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:29:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:12:\"vendors.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:14:\"vendors.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:12:\"vendors.edit\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:14:\"vendors.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:15:\"vendors.approve\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:15:\"vendors.suspend\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:10:\"users.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:12:\"users.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:10:\"users.edit\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:12:\"users.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:18:\"users.manage_roles\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:10:\"plans.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:12:\"plans.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:10:\"plans.edit\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:12:\"plans.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:18:\"subscriptions.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:20:\"subscriptions.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:18:\"subscriptions.edit\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:20:\"subscriptions.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:20:\"subscriptions.cancel\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:13:\"payments.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:21;a:4:{s:1:\"a\";i:22;s:1:\"b\";s:15:\"payments.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:22;a:4:{s:1:\"a\";i:23;s:1:\"b\";s:13:\"payments.edit\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:23;a:4:{s:1:\"a\";i:24;s:1:\"b\";s:15:\"payments.refund\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:24;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:13:\"settings.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:25;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:13:\"settings.edit\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:26;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:18:\"activity_logs.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:27;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:20:\"activity_logs.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:28;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:12:\"reports.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}}s:5:\"roles\";a:3:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:11:\"super_admin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:5:\"admin\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";i:3;s:1:\"b\";s:4:\"user\";s:1:\"c\";s:3:\"web\";}}}',1773313401);

/*Table structure for table `cache_locks` */

DROP TABLE IF EXISTS `cache_locks`;

CREATE TABLE `cache_locks` (
  `key` varchar(191) NOT NULL,
  `owner` varchar(191) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `cache_locks` */

/*Table structure for table `failed_jobs` */

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `failed_jobs` */

/*Table structure for table `job_batches` */

DROP TABLE IF EXISTS `job_batches`;

CREATE TABLE `job_batches` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `job_batches` */

/*Table structure for table `jobs` */

DROP TABLE IF EXISTS `jobs`;

CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `jobs` */

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2024_01_01_000003_create_plans_table',1),
(5,'2024_01_01_000004_create_vendors_table',1),
(6,'2024_01_01_000005_create_subscriptions_table',1),
(7,'2024_01_01_000006_create_subscription_items_table',1),
(8,'2024_01_01_000007_create_payments_table',1),
(9,'2024_01_01_000008_create_vendor_users_table',1),
(10,'2024_01_01_000009_create_activity_logs_table',1),
(11,'2024_01_01_000010_create_settings_table',1),
(12,'2024_01_01_000011_create_notifications_table',1),
(13,'2024_01_01_000012_create_vendor_invitations_table',1),
(14,'2024_01_01_000013_create_personal_access_tokens_table',1),
(15,'2026_03_08_213935_create_permission_tables',2);

/*Table structure for table `model_has_permissions` */

DROP TABLE IF EXISTS `model_has_permissions`;

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `model_has_permissions` */

/*Table structure for table `model_has_roles` */

DROP TABLE IF EXISTS `model_has_roles`;

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `model_has_roles` */

insert  into `model_has_roles`(`role_id`,`model_type`,`model_id`) values 
(1,'App\\Models\\User',1),
(2,'App\\Models\\User',2),
(3,'App\\Models\\User',3),
(3,'App\\Models\\User',4),
(3,'App\\Models\\User',5),
(3,'App\\Models\\User',6),
(3,'App\\Models\\User',7),
(3,'App\\Models\\User',8),
(3,'App\\Models\\User',9),
(3,'App\\Models\\User',10),
(3,'App\\Models\\User',11),
(3,'App\\Models\\User',12);

/*Table structure for table `notifications` */

DROP TABLE IF EXISTS `notifications`;

CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(191) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `notifications` */

/*Table structure for table `password_reset_tokens` */

DROP TABLE IF EXISTS `password_reset_tokens`;

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_reset_tokens` */

/*Table structure for table `payments` */

DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` bigint(20) unsigned NOT NULL,
  `subscription_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned DEFAULT NULL,
  `payment_number` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` enum('credit_card','debit_card','bank_transfer','paypal','stripe','manual','other') NOT NULL DEFAULT 'stripe',
  `payment_method_details` varchar(191) DEFAULT NULL,
  `stripe_payment_intent_id` varchar(191) DEFAULT NULL,
  `stripe_charge_id` varchar(191) DEFAULT NULL,
  `stripe_invoice_id` varchar(191) DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','refunded','partially_refunded','cancelled') NOT NULL DEFAULT 'pending',
  `paid_at` timestamp NULL DEFAULT NULL,
  `refunded_at` timestamp NULL DEFAULT NULL,
  `refunded_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `failure_reason` text DEFAULT NULL,
  `billing_name` varchar(191) DEFAULT NULL,
  `billing_email` varchar(191) DEFAULT NULL,
  `billing_address` varchar(191) DEFAULT NULL,
  `billing_city` varchar(191) DEFAULT NULL,
  `billing_state` varchar(191) DEFAULT NULL,
  `billing_country` varchar(191) DEFAULT NULL,
  `billing_postal_code` varchar(191) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_payment_number_unique` (`payment_number`),
  KEY `payments_user_id_foreign` (`user_id`),
  KEY `payments_plan_id_foreign` (`plan_id`),
  KEY `payments_vendor_id_index` (`vendor_id`),
  KEY `payments_subscription_id_index` (`subscription_id`),
  KEY `payments_status_index` (`status`),
  KEY `payments_payment_number_index` (`payment_number`),
  KEY `payments_stripe_payment_intent_id_index` (`stripe_payment_intent_id`),
  KEY `payments_paid_at_index` (`paid_at`),
  KEY `payments_vendor_id_status_index` (`vendor_id`,`status`),
  CONSTRAINT `payments_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `payments` */

insert  into `payments`(`id`,`vendor_id`,`subscription_id`,`user_id`,`plan_id`,`payment_number`,`description`,`amount`,`currency`,`tax_amount`,`discount_amount`,`total_amount`,`payment_method`,`payment_method_details`,`stripe_payment_intent_id`,`stripe_charge_id`,`stripe_invoice_id`,`status`,`paid_at`,`refunded_at`,`refunded_amount`,`failure_reason`,`billing_name`,`billing_email`,`billing_address`,`billing_city`,`billing_state`,`billing_country`,`billing_postal_code`,`metadata`,`notes`,`created_at`,`updated_at`,`deleted_at`) values 
(1,1,1,3,2,'PAY-20260308-3QOS0K','Subscription payment for Starter',9.00,'USD',0.90,0.00,9.90,'stripe',NULL,NULL,NULL,NULL,'pending','2026-02-26 07:20:46',NULL,0.00,NULL,'Zulauf-Ondricka','kohler.andre@nikolaus.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(2,2,2,4,4,'PAY-20260308-LIIDLX','Subscription payment for Enterprise',99.00,'USD',9.90,0.00,108.90,'stripe',NULL,NULL,NULL,NULL,'completed','2026-01-26 13:27:55',NULL,0.00,NULL,'Lind-Sanford','cierra48@sporer.org',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(3,2,2,4,4,'PAY-20260308-XWMPYM','Subscription payment for Enterprise',99.00,'USD',9.90,0.00,108.90,'stripe',NULL,NULL,NULL,NULL,'pending','2026-02-24 15:23:44',NULL,0.00,NULL,'Lind-Sanford','cierra48@sporer.org',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(4,3,3,5,3,'PAY-20260308-XZQBR0','Subscription payment for Professional',29.00,'USD',2.90,0.00,31.90,'stripe',NULL,NULL,NULL,NULL,'completed','2026-02-25 10:20:49',NULL,0.00,NULL,'Morissette-Haag','kozey.mayra@schinner.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(5,4,4,6,4,'PAY-20260308-AULSWM','Subscription payment for Enterprise',99.00,'USD',9.90,0.00,108.90,'stripe',NULL,NULL,NULL,NULL,'completed',NULL,NULL,0.00,NULL,'Beier PLC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(6,5,5,7,3,'PAY-20260308-FCGGVT','Subscription payment for Professional',29.00,'USD',2.90,0.00,31.90,'stripe',NULL,NULL,NULL,NULL,'completed',NULL,NULL,0.00,NULL,'Kutch Group','sebastian43@ledner.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(7,5,5,7,3,'PAY-20260308-YNWZJO','Subscription payment for Professional',29.00,'USD',2.90,0.00,31.90,'stripe',NULL,NULL,NULL,NULL,'completed',NULL,NULL,0.00,NULL,'Kutch Group','sebastian43@ledner.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(8,5,5,7,3,'PAY-20260308-6XM1EK','Subscription payment for Professional',29.00,'USD',2.90,0.00,31.90,'stripe',NULL,NULL,NULL,NULL,'completed','2026-02-28 10:08:31',NULL,0.00,NULL,'Kutch Group','sebastian43@ledner.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-08 21:40:04','2026-03-08 21:40:04',NULL),
(9,9,1,1,3,'PAY-20260308-ODONIT',NULL,9.00,'USD',0.00,1.00,8.00,'paypal','4554','54576htyuyu','12454','4555676','partially_refunded','2026-03-08 21:56:28','2026-03-11 11:55:07',6.00,NULL,'Saas','noor14@gmail.com','Peshawar','Peshawar',NULL,'Pakistan','25000','{\"yuyuyuyuy\":\"uyuyuy\"}','jhyj jmtyut','2026-03-08 21:56:10','2026-03-11 11:55:07',NULL);

/*Table structure for table `permissions` */

DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `permissions` */

insert  into `permissions`(`id`,`name`,`guard_name`,`created_at`,`updated_at`) values 
(1,'vendors.view','web','2026-03-08 21:39:58','2026-03-08 21:39:58'),
(2,'vendors.create','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(3,'vendors.edit','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(4,'vendors.delete','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(5,'vendors.approve','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(6,'vendors.suspend','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(7,'users.view','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(8,'users.create','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(9,'users.edit','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(10,'users.delete','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(11,'users.manage_roles','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(12,'plans.view','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(13,'plans.create','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(14,'plans.edit','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(15,'plans.delete','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(16,'subscriptions.view','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(17,'subscriptions.create','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(18,'subscriptions.edit','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(19,'subscriptions.delete','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(20,'subscriptions.cancel','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(21,'payments.view','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(22,'payments.create','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(23,'payments.edit','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(24,'payments.refund','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(25,'settings.view','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(26,'settings.edit','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(27,'activity_logs.view','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(28,'activity_logs.delete','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(29,'reports.view','web','2026-03-08 21:39:59','2026-03-08 21:39:59');

/*Table structure for table `personal_access_tokens` */

DROP TABLE IF EXISTS `personal_access_tokens`;

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `personal_access_tokens` */

/*Table structure for table `plans` */

DROP TABLE IF EXISTS `plans`;

CREATE TABLE `plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `billing_cycle` enum('monthly','yearly','lifetime') NOT NULL DEFAULT 'monthly',
  `trial_days` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `max_vendors` int(11) NOT NULL DEFAULT 1,
  `max_users_per_vendor` int(11) NOT NULL DEFAULT 5,
  `max_products` int(11) NOT NULL DEFAULT 100,
  `max_storage_mb` int(11) NOT NULL DEFAULT 1024,
  `max_api_calls_per_day` int(11) NOT NULL DEFAULT 1000,
  `has_custom_domain` tinyint(1) NOT NULL DEFAULT 0,
  `has_priority_support` tinyint(1) NOT NULL DEFAULT 0,
  `has_advanced_analytics` tinyint(1) NOT NULL DEFAULT 0,
  `has_white_label` tinyint(1) NOT NULL DEFAULT 0,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `stripe_price_id` varchar(191) DEFAULT NULL,
  `stripe_product_id` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_slug_unique` (`slug`),
  KEY `plans_slug_index` (`slug`),
  KEY `plans_is_active_index` (`is_active`),
  KEY `plans_is_default_index` (`is_default`),
  KEY `plans_stripe_price_id_index` (`stripe_price_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `plans` */

insert  into `plans`(`id`,`name`,`slug`,`description`,`price`,`currency`,`billing_cycle`,`trial_days`,`is_active`,`is_featured`,`is_default`,`sort_order`,`max_vendors`,`max_users_per_vendor`,`max_products`,`max_storage_mb`,`max_api_calls_per_day`,`has_custom_domain`,`has_priority_support`,`has_advanced_analytics`,`has_white_label`,`features`,`metadata`,`stripe_price_id`,`stripe_product_id`,`created_at`,`updated_at`,`deleted_at`) values 
(1,'Free222','free','Perfect for getting started with basic features.',0.00,'USD','monthly',0,1,0,0,1,1,2,20,100,100,0,0,0,0,'[{\"icon\":\"heroicon-o-check\",\"label\":\"Up to 20 products\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"2 team members\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"100 MB storage\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"Email support\",\"value\":null}]','[]',NULL,NULL,'2026-03-08 21:40:02','2026-03-11 11:48:59',NULL),
(2,'Starter','starter','Great for small businesses and startups.',9.00,'USD','monthly',14,1,0,0,2,1,5,100,1024,1000,0,0,0,0,'[{\"icon\":\"heroicon-o-check\",\"label\":\"Up to 100 products\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"5 team members\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"1 GB storage\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Priority email support\",\"value\":\"\"}]',NULL,NULL,NULL,'2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(3,'Professional','professional','Best for growing businesses with advanced needs.',29.00,'USD','monthly',14,1,1,0,3,1,15,500,5120,10000,1,1,1,0,'[{\"icon\":\"heroicon-o-check\",\"label\":\"Up to 500 products\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"15 team members\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"5 GB storage\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Custom domain\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Priority support\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Advanced analytics\",\"value\":\"\"}]',NULL,NULL,NULL,'2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(4,'Enterprise','enterprise','For large organizations with unlimited needs.',99.00,'USD','monthly',30,1,0,0,4,1,-1,-1,-1,-1,1,1,1,1,'[{\"icon\":\"heroicon-o-check\",\"label\":\"Unlimited products\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Unlimited team members\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Unlimited storage\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Custom domain\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"24\\/7 Priority support\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"Advanced analytics\",\"value\":\"\"},{\"icon\":\"heroicon-o-check\",\"label\":\"White label option\",\"value\":\"\"}]',NULL,NULL,NULL,'2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(5,'Free222 (Copy)','free-copy','Perfect for getting started with basic features.',0.00,'USD','monthly',0,1,0,1,1,1,2,20,100,100,0,0,0,0,'[{\"icon\":\"heroicon-o-check\",\"label\":\"Up to 20 products\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"2 team members\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"100 MB storage\",\"value\":null},{\"icon\":\"heroicon-o-check\",\"label\":\"Email support\",\"value\":null}]','[]',NULL,NULL,'2026-03-11 11:48:37','2026-03-11 11:49:07','2026-03-11 11:49:07');

/*Table structure for table `role_has_permissions` */

DROP TABLE IF EXISTS `role_has_permissions`;

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `role_has_permissions` */

insert  into `role_has_permissions`(`permission_id`,`role_id`) values 
(1,1),
(1,2),
(1,3),
(2,1),
(2,2),
(3,1),
(3,2),
(4,1),
(5,1),
(5,2),
(6,1),
(6,2),
(7,1),
(7,2),
(8,1),
(8,2),
(9,1),
(9,2),
(10,1),
(11,1),
(12,1),
(12,2),
(13,1),
(13,2),
(14,1),
(14,2),
(15,1),
(16,1),
(16,2),
(17,1),
(17,2),
(18,1),
(18,2),
(19,1),
(20,1),
(20,2),
(21,1),
(21,2),
(22,1),
(22,2),
(23,1),
(23,2),
(24,1),
(24,2),
(25,1),
(25,2),
(26,1),
(26,2),
(27,1),
(27,2),
(28,1),
(29,1),
(29,2);

/*Table structure for table `roles` */

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `roles` */

insert  into `roles`(`id`,`name`,`guard_name`,`created_at`,`updated_at`) values 
(1,'super_admin','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(2,'admin','web','2026-03-08 21:39:59','2026-03-08 21:39:59'),
(3,'user','web','2026-03-08 21:39:59','2026-03-08 21:39:59');

/*Table structure for table `sessions` */

DROP TABLE IF EXISTS `sessions`;

CREATE TABLE `sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `sessions` */

insert  into `sessions`(`id`,`user_id`,`ip_address`,`user_agent`,`payload`,`last_activity`) values 
('BxbtTzTbAR6vaCY7slF5rLPSEzCaraHGvrAurUUU',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','YTo3OntzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozNjoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2FkbWluL3NldHRpbmdzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo2OiJfdG9rZW4iO3M6NDA6Imw4MUpJbDEzdjVKY0ZRVnBTWmRPc3FLS1ZYdVdJTjFaaG9Xa0hNZ20iO3M6MzoidXJsIjthOjA6e31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTIkVU5YeGdmRHc5dWhMeHRmdDQ4d09ndTY2OFNjalE2aFFZdUlEYlZOVXdvR2dNMFcwcjIvNlciO3M6ODoiZmlsYW1lbnQiO2E6MDp7fX0=',1773230156);

/*Table structure for table `settings` */

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(191) NOT NULL DEFAULT 'general',
  `key` varchar(191) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'string',
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_group_key_unique` (`group`,`key`),
  KEY `settings_group_index` (`group`),
  KEY `settings_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `settings` */

insert  into `settings`(`id`,`group`,`key`,`value`,`type`,`is_public`,`description`,`created_at`,`updated_at`) values 
(1,'general','site_name','SaaS Platform','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(2,'general','site_description','Multi-Vendor SaaS Platform','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(3,'general','default_timezone','UTC','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(4,'general','default_currency','USD','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(5,'general','date_format','Y-m-d','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(6,'general','time_format','H:i','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(7,'branding','logo','Saas(78','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 22:14:42'),
(8,'branding','favicon','','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(9,'branding','primary_color','#3B82F6','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(10,'branding','secondary_color','#10B981','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(11,'email','from_name','SaaS Platform','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(12,'email','from_address','noreply@example.com','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(13,'email','enable_notifications','1','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(14,'payment','default_currency','USD','string',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(15,'payment','tax_rate','0','float',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(16,'payment','enable_invoicing','1','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(17,'security','require_email_verification','1','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(18,'security','two_factor_auth','0','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(19,'security','password_min_length','8','integer',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(20,'security','session_lifetime','120','integer',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(21,'features','enable_registration','1','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(22,'features','enable_vendor_registration','1','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(23,'features','require_vendor_approval','1','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(24,'features','enable_trial','1','boolean',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59'),
(25,'features','trial_days','14','integer',0,NULL,'2026-03-08 21:39:59','2026-03-08 21:39:59');

/*Table structure for table `subscription_items` */

DROP TABLE IF EXISTS `subscription_items`;

CREATE TABLE `subscription_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned NOT NULL,
  `stripe_id` varchar(191) NOT NULL,
  `stripe_product` varchar(191) NOT NULL,
  `stripe_price` varchar(191) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscription_items_stripe_id_unique` (`stripe_id`),
  KEY `subscription_items_plan_id_foreign` (`plan_id`),
  KEY `subscription_items_subscription_id_index` (`subscription_id`),
  KEY `subscription_items_stripe_id_index` (`stripe_id`),
  CONSTRAINT `subscription_items_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`),
  CONSTRAINT `subscription_items_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `subscription_items` */

/*Table structure for table `subscriptions` */

DROP TABLE IF EXISTS `subscriptions`;

CREATE TABLE `subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` bigint(20) unsigned NOT NULL,
  `plan_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'default',
  `status` enum('active','trialing','past_due','canceled','unpaid','incomplete','incomplete_expired') NOT NULL DEFAULT 'incomplete',
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `canceled_at` timestamp NULL DEFAULT NULL,
  `stripe_id` varchar(191) DEFAULT NULL,
  `stripe_status` varchar(191) DEFAULT NULL,
  `stripe_price` varchar(191) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `billing_cycle` enum('monthly','yearly','lifetime') NOT NULL DEFAULT 'monthly',
  `current_period_start` timestamp NULL DEFAULT NULL,
  `current_period_end` timestamp NULL DEFAULT NULL,
  `cancel_at_period_end` tinyint(1) NOT NULL DEFAULT 0,
  `cancel_at` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscriptions_stripe_id_unique` (`stripe_id`),
  KEY `subscriptions_user_id_foreign` (`user_id`),
  KEY `subscriptions_vendor_id_index` (`vendor_id`),
  KEY `subscriptions_plan_id_index` (`plan_id`),
  KEY `subscriptions_status_index` (`status`),
  KEY `subscriptions_stripe_id_index` (`stripe_id`),
  KEY `subscriptions_current_period_end_index` (`current_period_end`),
  KEY `subscriptions_vendor_id_status_index` (`vendor_id`,`status`),
  CONSTRAINT `subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`),
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `subscriptions` */

insert  into `subscriptions`(`id`,`vendor_id`,`plan_id`,`user_id`,`type`,`status`,`starts_at`,`ends_at`,`trial_ends_at`,`canceled_at`,`stripe_id`,`stripe_status`,`stripe_price`,`quantity`,`amount`,`currency`,`billing_cycle`,`current_period_start`,`current_period_end`,`cancel_at_period_end`,`cancel_at`,`metadata`,`created_at`,`updated_at`,`deleted_at`) values 
(1,1,2,3,'default','active','2026-03-04 21:40:03',NULL,NULL,NULL,NULL,NULL,NULL,1,9.00,'USD','monthly','2026-03-02 21:40:03','2026-04-06 21:40:03',0,NULL,NULL,'2026-03-08 21:40:03','2026-03-11 11:53:33',NULL),
(2,2,4,4,'default','active','2026-02-13 21:40:03',NULL,NULL,NULL,NULL,NULL,NULL,1,99.00,'USD','monthly','2026-03-07 21:40:03','2026-04-03 21:40:03',0,NULL,NULL,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(3,3,3,5,'default','trialing','2026-02-22 21:40:03',NULL,NULL,NULL,NULL,NULL,NULL,1,29.00,'USD','monthly','2026-02-15 21:40:03','2026-03-31 21:40:03',0,NULL,NULL,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(4,4,4,6,'default','active','2026-01-29 21:40:03',NULL,NULL,NULL,NULL,NULL,NULL,1,99.00,'USD','monthly','2026-03-04 21:40:03','2026-04-01 21:40:03',0,NULL,NULL,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(5,5,3,7,'default','active','2026-01-28 21:40:03',NULL,'2026-03-20 11:34:14',NULL,NULL,NULL,NULL,1,29.00,'USD','monthly','2026-02-27 21:40:03','2026-03-11 21:40:03',0,NULL,NULL,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(191) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_status_index` (`status`),
  KEY `users_email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`email_verified_at`,`password`,`avatar`,`phone`,`bio`,`status`,`last_login_at`,`last_login_ip`,`remember_token`,`created_at`,`updated_at`,`deleted_at`) values 
(1,'Super Admin','admin@saas.com','2026-03-08 21:39:59','$2y$12$UNXxgfDw9uhLxtft48wOgu668ScjQ6hQYuIDbVNUwoGgM0W0r2/6W',NULL,NULL,NULL,'active','2026-03-11 11:34:32','127.0.0.1',NULL,'2026-03-08 21:39:59','2026-03-11 11:34:32',NULL),
(2,'Admin User','admin2@saas.com','2026-03-08 21:39:59','$2y$12$Zj9BDhPdwJyhx7lmFCDjQeihHFaT8bCkcJ.UnZpSQ7i6nqSVNciki',NULL,NULL,NULL,'active','2026-03-11 11:27:57','127.0.0.1',NULL,'2026-03-08 21:39:59','2026-03-11 11:27:57',NULL),
(3,'Casimir Adams','jazmyn.hyatt@example.com','2026-03-08 21:39:59','$2y$12$myof1FbnqXoQktYaLCfCNOp0ihVo01jmdMTZpaYONXNJKnRDTqLly',NULL,NULL,NULL,'active','2026-03-08 22:01:17','127.0.0.1','4mizx3q37fDJ1gZMUbZp0xZJKMRv5dV5vRo9kxGFvYTaUBOzgj8l84XF1GWC','2026-03-08 21:40:02','2026-03-08 22:01:17',NULL),
(4,'Kamron Goldner V','jklocko@example.net','2026-03-08 21:40:00','$2y$12$E8mPLgaRpoveGnvhr4Y8vu/A/ZLCb2lS71fCKzPDPMSSC1g9zTeS.',NULL,'(442) 295-7505',NULL,'active','2026-03-01 01:28:39','241.65.37.45','R95BF8VCnQ','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(5,'Dr. Alysa Pagac DVM','gerlach.hilda@example.com','2026-03-08 21:40:00','$2y$12$SAmO52p1lQ3m9a/zNC6SQugSXNdKbyVNDaeFy47CtzO/WBWhvMNsO',NULL,NULL,NULL,'active',NULL,'187.8.35.29','yyPZLfGy6q','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(6,'Reed Funk','leopoldo04@example.com','2026-03-08 21:40:00','$2y$12$0mFRmrZ96YatqrYtu9dB1OG6sZkuEANjP5zUtLXItiVDuV1OhtnO2',NULL,NULL,'Aut voluptate fugiat velit. Omnis dolore recusandae ut vel. Consequatur ipsam fuga accusantium.','active','2026-02-08 09:01:11','113.224.67.175','577bTL3f2m','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(7,'Aurelia Rosenbaum','legros.constance@example.com','2026-03-08 21:40:00','$2y$12$57XngQSH1RKPFIad8DcuhuIvLoQ7Hgodt9.5RblV9XH0x4An.dBTe',NULL,'+14238865068',NULL,'inactive','2026-02-12 13:51:32',NULL,'3kb4sH3L3F','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(8,'Carolyn Murphy','rebeka85@example.net','2026-03-08 21:40:01','$2y$12$OV154HlSElJBwtpoLwmAXOVtIWMBRyNYZ1cme73ffefX0DKMtUPIK',NULL,'(605) 621-9161','Quis occaecati est sapiente illum et placeat rem. Ut rerum placeat est ullam et eum laudantium. Aut eum dolor sit hic qui atque quibusdam ut. Magnam veniam unde voluptates minima. Velit qui porro voluptatibus.','inactive',NULL,NULL,'8sw5XfzaWX','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(9,'Kaitlyn Hermann','sawayn.renee@example.net','2026-03-08 21:40:01','$2y$12$z7QBplSQCjr24p.7JpdUK.R9Keiiler9EVwgdKWC/DPFyH149Isry',NULL,'267.868.5978',NULL,'active',NULL,NULL,'bZVQnGBsEl','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(10,'Morris Jones','dolores28@example.com','2026-03-08 21:40:01','$2y$12$E6DiN09GF.t0RJoi5R5s8eR9bM1rrSS1ycQDAYHh0q5onfMasm39u',NULL,NULL,'Architecto sed quas amet qui ullam minus possimus. Possimus et ullam tenetur aut. Facilis qui accusamus quia dolorem.','active','2026-02-10 05:59:21','41.57.44.127','6pZjqKeK5B','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(11,'Deshaun Wisozk','stanton.chaz@example.org','2026-03-08 21:40:01','$2y$12$pSyVionPhCg1NY5WhUhOge4YS1/LiJh8g3U7e/6Q4O0i9RLJqJ0du',NULL,NULL,NULL,'inactive','2026-03-07 20:39:08',NULL,'oVk4lTROZb','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(12,'Carol Steuber I','vincenza.stoltenberg@example.org','2026-03-08 21:40:02','$2y$12$1JV8DuXNVnl.z5WZED3./OK4yTy4x4zWgZGO44V36RLHHQB81RduW',NULL,'+1.678.300.0515',NULL,'active','2026-03-03 19:14:34',NULL,'We6IYJGeQU','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(13,'Mrs. Aileen Spencer','kadams@example.com','2026-03-08 21:40:02','$2y$12$MD36k5iml2CnBjRP5lvz1eg3IBgU.cmMMO515ZehHn2v693FdCjnm',NULL,'351-848-6022','Soluta iste qui repudiandae itaque. Necessitatibus et non ullam quasi. Ut velit et ut adipisci optio in voluptatum.','inactive',NULL,NULL,'GGk9LdK65U','2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(14,'Jeffery Mitchell','alyce67@example.org','2026-03-08 21:40:02','$2y$12$cJRiKHNl4l/9gufCSEfx.Oiwq0UmXQAItmZ426L7pwJgP5BN.kubq',NULL,NULL,'Quia dolorum culpa adipisci et dolorum autem suscipit sint. Voluptas minima omnis eligendi ut harum occaecati nihil. Voluptates repellendus nemo quis et.','active',NULL,'21.81.217.70','tuIk63dsjd','2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(15,'Torrance Ortiz DVM','josianne99@example.org','2026-03-08 21:40:03','$2y$12$sL1e026P8HiqMDpNUX0OH.E94BhrIr7wBjegPY5mKRfOfkSrLB04y',NULL,NULL,NULL,'active','2026-03-07 18:24:11',NULL,'0hWE6Coj0P','2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(16,'Ethelyn Smith','lcorwin@example.net','2026-03-08 21:40:03','$2y$12$OmpmvhzZ2QvROHpBsrBHQ.NMkeOvZwU/e/ZGxJMydeGo0VHVh7E2y',NULL,'301.427.1102','Sed perspiciatis expedita magnam ut laborum id. Et voluptatum sit ex impedit. Non a dignissimos suscipit.','active',NULL,'89.229.186.242','pUC9ECUpL2','2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(17,'Jan Weissnat','raegan53@example.net','2026-03-08 21:40:03','$2y$12$2fC9StOgWZ6DLOnXtgWWYuZXBXY0xDD3ukT6oYOHcfIpPdZf7MRoK',NULL,NULL,NULL,'active',NULL,NULL,'H77iBxgfv7','2026-03-08 21:40:03','2026-03-08 21:40:03',NULL);

/*Table structure for table `vendor_invitations` */

DROP TABLE IF EXISTS `vendor_invitations`;

CREATE TABLE `vendor_invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` bigint(20) unsigned NOT NULL,
  `invited_by` bigint(20) unsigned NOT NULL,
  `email` varchar(191) NOT NULL,
  `role` enum('admin','manager','staff','viewer') NOT NULL DEFAULT 'staff',
  `token` varchar(64) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `accepted_at` timestamp NULL DEFAULT NULL,
  `accepted_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_invitations_token_unique` (`token`),
  KEY `vendor_invitations_invited_by_foreign` (`invited_by`),
  KEY `vendor_invitations_accepted_by_foreign` (`accepted_by`),
  KEY `vendor_invitations_vendor_id_index` (`vendor_id`),
  KEY `vendor_invitations_token_index` (`token`),
  KEY `vendor_invitations_email_index` (`email`),
  KEY `vendor_invitations_expires_at_index` (`expires_at`),
  CONSTRAINT `vendor_invitations_accepted_by_foreign` FOREIGN KEY (`accepted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vendor_invitations_invited_by_foreign` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vendor_invitations_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vendor_invitations` */

/*Table structure for table `vendor_users` */

DROP TABLE IF EXISTS `vendor_users`;

CREATE TABLE `vendor_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `role` enum('owner','admin','manager','staff','viewer') NOT NULL DEFAULT 'staff',
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `status` enum('active','inactive','invited','suspended') NOT NULL DEFAULT 'invited',
  `invited_at` timestamp NULL DEFAULT NULL,
  `joined_at` timestamp NULL DEFAULT NULL,
  `department` varchar(191) DEFAULT NULL,
  `job_title` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_users_vendor_id_user_id_unique` (`vendor_id`,`user_id`),
  KEY `vendor_users_vendor_id_index` (`vendor_id`),
  KEY `vendor_users_user_id_index` (`user_id`),
  KEY `vendor_users_role_index` (`role`),
  KEY `vendor_users_status_index` (`status`),
  CONSTRAINT `vendor_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vendor_users_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vendor_users` */

/*Table structure for table `vendors` */

DROP TABLE IF EXISTS `vendors`;

CREATE TABLE `vendors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `favicon` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `postal_code` varchar(191) DEFAULT NULL,
  `business_type` varchar(191) DEFAULT NULL,
  `tax_id` varchar(191) DEFAULT NULL,
  `registration_number` varchar(191) DEFAULT NULL,
  `status` enum('pending','approved','rejected','suspended','inactive') NOT NULL DEFAULT 'pending',
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `custom_domain` varchar(191) DEFAULT NULL,
  `custom_domain_verified` tinyint(1) NOT NULL DEFAULT 0,
  `primary_color` varchar(191) DEFAULT NULL,
  `secondary_color` varchar(191) DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `total_users` int(11) NOT NULL DEFAULT 0,
  `total_products` int(11) NOT NULL DEFAULT 0,
  `total_orders` int(11) NOT NULL DEFAULT 0,
  `total_revenue` decimal(15,2) NOT NULL DEFAULT 0.00,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `is_trial` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendors_slug_unique` (`slug`),
  UNIQUE KEY `vendors_custom_domain_unique` (`custom_domain`),
  KEY `vendors_approved_by_foreign` (`approved_by`),
  KEY `vendors_slug_index` (`slug`),
  KEY `vendors_status_index` (`status`),
  KEY `vendors_owner_id_index` (`owner_id`),
  KEY `vendors_custom_domain_index` (`custom_domain`),
  KEY `vendors_trial_ends_at_index` (`trial_ends_at`),
  CONSTRAINT `vendors_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vendors_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `vendors` */

insert  into `vendors`(`id`,`owner_id`,`name`,`slug`,`description`,`email`,`phone`,`website`,`logo`,`favicon`,`address`,`city`,`state`,`country`,`postal_code`,`business_type`,`tax_id`,`registration_number`,`status`,`approved_at`,`approved_by`,`rejection_reason`,`custom_domain`,`custom_domain_verified`,`primary_color`,`secondary_color`,`settings`,`total_users`,`total_products`,`total_orders`,`total_revenue`,`trial_ends_at`,`is_trial`,`created_at`,`updated_at`,`deleted_at`) values 
(1,3,'Zulauf-Ondricka','zulauf-ondricka','Asperiores excepturi excepturi consequuntur qui sint doloribus. Asperiores dolores animi possimus quod minus. Earum quas sit velit est aut repellat molestias. Voluptas maiores quo numquam sunt assumenda officiis deleniti.','kohler.andre@nikolaus.com','+1-631-432-3115',NULL,NULL,NULL,'89405 Patrick Coves',NULL,NULL,NULL,NULL,NULL,'K0WDIIQRO0','4969KTSY','approved','2026-03-08 21:40:02',1,NULL,NULL,0,NULL,NULL,'[]',0,23,720,23092.13,'2026-03-17 23:25:16',0,'2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(2,4,'Lind-Sanford','lind-sanford',NULL,'cierra48@sporer.org','+1 (303) 508-1329','http://www.ward.net/quis-eius-dolore-dolorem-expedita',NULL,NULL,NULL,NULL,NULL,NULL,'59348',NULL,NULL,NULL,'approved','2026-03-08 21:40:02',1,NULL,NULL,0,'#5e28e2',NULL,'[]',0,53,4445,96141.98,NULL,0,'2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(3,5,'Morissette-Haag','morissette-haag','Quas voluptate qui fugiat provident esse earum minus. Velit cum id blanditiis esse labore enim ducimus similique. Ab harum et quis aut aliquam voluptas accusantium. Ipsa debitis voluptatum impedit doloremque.','kozey.mayra@schinner.com',NULL,'http://www.schuppe.org/',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved','2026-03-08 21:40:02',1,NULL,NULL,0,'#c9e849','#f4f3a5','{\"Coffee\":null}',0,839,598,97816.96,'2026-03-17 00:01:38',0,'2026-03-08 21:40:02','2026-03-08 21:51:38',NULL),
(4,6,'Beier PLC','beier-plc','Fugit est vel fugiat cumque perferendis voluptate veniam saepe. Error repudiandae saepe ut sed. Sequi quia reiciendis quisquam voluptates qui sint numquam. Repudiandae voluptatibus quaerat recusandae dolorem qui doloremque sunt.',NULL,NULL,'https://tromp.org/et-voluptas-accusamus-consequuntur-vel.html',NULL,NULL,'507 Devan Crossing',NULL,'North Carolina','Madagascar','84470-7718','Sole Proprietorship','P1GB88XRVB',NULL,'approved','2026-03-08 21:40:02',1,NULL,NULL,0,NULL,'#44a1dc','[]',0,838,720,12605.03,'2026-03-09 04:11:19',0,'2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(5,7,'Kutch Group','kutch-group','Et magni dolorem eos voluptatem sit. Ratione dolorem similique et eveniet illo aperiam.','sebastian43@ledner.com','(727) 201-3767','https://www.zulauf.com/quia-dolores-voluptatem-deserunt-tenetur-porro',NULL,NULL,'4620 Karlee Plains Suite 343',NULL,'New Hampshire',NULL,'99455-1304',NULL,NULL,'PEN8EM6F','approved','2026-03-08 21:40:02',1,NULL,NULL,0,'#d42df3',NULL,'[]',0,903,4350,60072.20,'2026-04-04 09:11:47',1,'2026-03-08 21:40:02','2026-03-08 21:40:02',NULL),
(6,13,'Dickinson Ltd','dickinson-ltd',NULL,NULL,NULL,'http://abbott.com/consequatur-non-voluptates-at-accusantium-ut-aut-aperiam.html',NULL,NULL,NULL,'East Nia','Vermont',NULL,'51430',NULL,NULL,'38GZ2VT5','pending',NULL,NULL,NULL,NULL,0,NULL,NULL,'[]',0,419,2846,87572.66,NULL,0,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(7,14,'Fritsch Inc','fritsch-inc',NULL,NULL,'+1.678.223.1081',NULL,NULL,NULL,'1379 Bonnie Fort Apt. 213',NULL,'Montana',NULL,'32747-5634','Partnership',NULL,NULL,'pending',NULL,NULL,NULL,NULL,0,'#9ed66f',NULL,'[]',0,928,2799,47060.27,NULL,0,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(8,15,'Rogahn, Botsford and Jacobi','rogahn-botsford-and-jacobi','Ut laborum at adipisci nulla repellendus enim. Odio quam libero voluptatibus accusamus. Optio quibusdam ut neque voluptatum autem. Eum expedita temporibus eius et omnis. Consequatur veritatis explicabo eos temporibus aperiam itaque fugit.',NULL,'1-563-559-5404',NULL,NULL,NULL,NULL,'South Dino','Virginia',NULL,NULL,'Corporation',NULL,'1H17PVJE','pending',NULL,NULL,NULL,NULL,0,NULL,NULL,'[]',0,67,8,20254.61,NULL,0,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(9,16,'Batz, Koepp and Mante','batz-koepp-and-mante',NULL,'thudson@thompson.com',NULL,NULL,NULL,NULL,'3963 Alanis Fall',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'suspended',NULL,NULL,NULL,NULL,0,'#a50bc3',NULL,'[]',0,869,279,70744.90,NULL,1,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(10,17,'Schmeler, Stiedemann and Pagac','schmeler-stiedemann-and-pagac','Enim perferendis ducimus deserunt minima dolor quasi vel. Animi hic quia quia ipsam aut et excepturi. Repellat ea nulla dignissimos et quibusdam voluptate voluptates dolorum. Quasi dignissimos dicta eaque eveniet.','jevon.baumbach@stracke.org','+1 (551) 541-0771','http://ratke.com/',NULL,NULL,NULL,'Hyatttown',NULL,'Guam','21839-8060',NULL,'BFCSGKZYV7','N8EPN5RM','suspended',NULL,NULL,NULL,NULL,0,'#4597d2','#34157f','[]',0,888,1451,68425.94,'2026-03-10 17:13:36',0,'2026-03-08 21:40:03','2026-03-08 21:40:03',NULL),
(11,2,'Testing1','testing1','This is testing of testing1','test@test.com','12245564','http://www.schuppe.org/',NULL,NULL,'Peshawar','Peshawar','kpk','Pakistan','25000','Normal','242ZXSDe','ETRDVCR65','suspended',NULL,NULL,NULL,'customer.com',0,'#eb1d1d','#948080','{\"test\":\"245\"}',0,0,0,0.00,'2026-03-25 11:08:34',1,'2026-03-11 11:08:34','2026-03-11 11:11:39',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
